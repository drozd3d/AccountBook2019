<?php

return[
	//template setting
	'view_front' =>[
	'template_dir' => BASEPATH . '/template/front',
	],
];