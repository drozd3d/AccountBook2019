<?php  // test_config_read.php

$config = require('./test_config.php');
var_dump($config);




