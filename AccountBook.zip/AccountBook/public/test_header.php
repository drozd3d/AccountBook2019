<?php  // test_header.php

var_dump($_COOKIE);

//
setcookie('test', mt_rand(0, 99));

var_dump($_COOKIE);
