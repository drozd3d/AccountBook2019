<?php // reminder_success.php

// 初期処理
require_once(__DIR__ . '/../Libs/init.php');

//
$template_file_name = 'reminder_success.twig';
$template_data = [];

// 終了処理
require_once(BASEPATH . '/Libs/fin.php');
