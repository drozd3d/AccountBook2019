<?php

return [
	't1' => 10,
	't2' => 'test',
	't3' => [1,2,3]
];