<?php
	return[
	'DB' =>[
		'dbname' => 'AccountBook',
		'host'   => 'localhost',
		'user'   => 'AccountBook',
		'pass'   => 'AccountBook',
		],
	];